const properties = [
  {id:1,title:"Sunny Nest Apartment",city:"Chennai",locality:"Adyar, Chennai",rent:14500,deposit:50000,room:"1 BHK",furnishing:"Semi-furnished",amenities:["Balcony","Water supply","Near bus stop"],moveIn:"Available now",art:"⌂",artClass:"",tag:"GOOD VALUE",owner:"Sample Owner A"},
  {id:2,title:"Greenview Shared Home",city:"Chennai",locality:"Velachery, Chennai",rent:7500,deposit:15000,room:"Shared room",furnishing:"Furnished",amenities:["Wi-Fi","Laundry","Public transport"],moveIn:"From 1 Nov",art:"⌂",artClass:"alt",tag:"FURNISHED",owner:"Sample Owner B"},
  {id:3,title:"Citylight Family Flat",city:"Chennai",locality:"Anna Nagar, Chennai",rent:22000,deposit:80000,room:"2 BHK",furnishing:"Unfurnished",amenities:["Lift","Parking","Market nearby"],moveIn:"Available now",art:"⌂",artClass:"third",tag:"SPACIOUS",owner:"Sample Owner C"},
  {id:4,title:"Compact Studio Space",city:"Bengaluru",locality:"HSR Layout, Bengaluru",rent:12000,deposit:36000,room:"Studio",furnishing:"Furnished",amenities:["Kitchenette","Wi-Fi","Security desk"],moveIn:"From 5 Nov",art:"⌂",artClass:"alt",tag:"MOVE-IN SOON",owner:"Sample Owner D"},
  {id:5,title:"Quiet Corner Home",city:"Coimbatore",locality:"Peelamedu, Coimbatore",rent:10000,deposit:25000,room:"1 BHK",furnishing:"Semi-furnished",amenities:["Two-wheeler parking","Water supply","Shops nearby"],moveIn:"Available now",art:"⌂",artClass:"third",tag:"BUDGET PICK",owner:"Sample Owner E"},
  {id:6,title:"Sunrise Shared Flat",city:"Bengaluru",locality:"Marathahalli, Bengaluru",rent:8500,deposit:20000,room:"Shared room",furnishing:"Furnished",amenities:["Wi-Fi","Housekeeping","Bus access"],moveIn:"From 10 Nov",art:"⌂",artClass:"",tag:"SHARED LIVING",owner:"Sample Owner F"}
];
const $ = id => document.getElementById(id);
const saved = new Set();
let activeProperty = null;

function render() {
  const location = $("locationFilter").value.trim().toLowerCase();
  const maxRent = Number($("rentFilter").value) || Infinity;
  const room = $("roomFilter").value;
  const furnishing = $("furnishFilter").value;
  const matches = properties.filter(p =>
    (!location || `${p.city} ${p.locality} ${p.title}`.toLowerCase().includes(location)) &&
    p.rent <= maxRent && (!room || p.room === room) && (!furnishing || p.furnishing === furnishing)
  );
  $("resultCount").textContent = `Showing ${matches.length} ${matches.length === 1 ? "home" : "homes"}`;
  $("emptyState").hidden = matches.length > 0;
  $("listingGrid").innerHTML = matches.map(p => `
    <article class="listing-card">
      <div class="property-art ${p.artClass}"><span class="art-label">${p.tag}</span><span aria-hidden="true">${p.art}</span>
        <button class="favorite-btn ${saved.has(p.id) ? "saved" : ""}" data-favorite="${p.id}" aria-label="${saved.has(p.id) ? "Remove from" : "Add to"} favourites">${saved.has(p.id) ? "♥" : "♡"}</button>
      </div>
      <div class="listing-body">
        <div class="listing-top"><h3>${p.title}</h3><div class="price">₹${p.rent.toLocaleString("en-IN")}<small>/mo</small></div></div>
        <p class="locality">⌖ ${p.locality}</p>
        <div class="facts"><span class="fact">${p.room}</span><span class="fact">${p.furnishing}</span><span class="fact">${p.moveIn}</span></div>
        <div class="amenities">${p.amenities.join(" · ")}</div>
        <div class="deposit">Deposit: ₹${p.deposit.toLocaleString("en-IN")}</div>
        <div class="card-actions"><button class="primary-btn" data-contact="${p.id}">Enquire</button><button class="secondary-btn" data-details="${p.id}">Compare details</button></div>
        <button class="report-btn" data-report="${p.id}">⚑ Report outdated / suspicious listing</button>
      </div>
    </article>`).join("");
}
["locationFilter","rentFilter","roomFilter","furnishFilter"].forEach(id => $(id).addEventListener("input", render));
$("resetBtn").addEventListener("click", () => {["locationFilter","rentFilter","roomFilter","furnishFilter"].forEach(id => $(id).value = ""); render();});
$("listingGrid").addEventListener("click", event => {
  const fav = event.target.closest("[data-favorite]");
  const contact = event.target.closest("[data-contact]");
  const details = event.target.closest("[data-details]");
  const report = event.target.closest("[data-report]");
  if (fav) { const id = Number(fav.dataset.favorite); saved.has(id) ? saved.delete(id) : saved.add(id); render(); }
  if (contact) {
    activeProperty = properties.find(p => p.id === Number(contact.dataset.contact));
    $("dialogTitle").textContent = `Enquire: ${activeProperty.title}`;
    $("dialogText").textContent = `Demo only. Listed contact: ${activeProperty.owner}. No message will be sent and this is not a verified owner.`;
    $("enquiryFeedback").textContent = "";
    $("contactDialog").showModal();
  }
  if (details) {
    const p = properties.find(item => item.id === Number(details.dataset.details));
    alert(`${p.title}\nLocation: ${p.locality}\nRent: ₹${p.rent.toLocaleString("en-IN")}/month\nDeposit: ₹${p.deposit.toLocaleString("en-IN")}\nRoom: ${p.room}\nFurnishing: ${p.furnishing}\nMove-in: ${p.moveIn}\nAmenities: ${p.amenities.join(", ")}\n\nSample listing only. Confirm all details independently.`);
  }
  if (report) {
    const p = properties.find(item => item.id === Number(report.dataset.report));
    alert(`Demo report recorded locally for "${p.title}". In a production version, this would be sent for review. No report has been sent to a server.`);
  }
});
$("prepareEnquiry").addEventListener("click", () => {
  const name = $("enquiryName").value.trim();
  const message = $("enquiryMessage").value.trim();
  $("enquiryFeedback").textContent = name && message ? "Your demo enquiry is ready. Nothing has been sent; connect a backend to enable real enquiries." : "Please enter your name and a message.";
});
render();
